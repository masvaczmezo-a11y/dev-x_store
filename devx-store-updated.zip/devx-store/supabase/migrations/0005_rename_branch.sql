-- شغّلها مرة واحدة في Supabase → SQL Editor (لو قاعدة البيانات اتعملت قبل التعديل)
update public.branches set name = 'براح' where name in ('براج الدقي', 'فراح');
