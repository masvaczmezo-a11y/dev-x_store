(function(){
  const db=window.__fake={tables:{},session:null,listeners:[],rt:[],emails:[],uploads:[],otp:'123456',admins:{}};
  const T=n=>db.tables[n]||(db.tables[n]=[]);
  const NEXT={new:['preparing','cancelled'],preparing:['contacted','cancelled'],contacted:['confirmed','cancelled'],confirmed:['delivered','cancelled']};
  class Q{constructor(t){this.t=t;this.f=[];this.op='select'}
    select(){return this} eq(k,v){this.f.push([k,v]);return this} order(){return this} single(){this.one=true;return this} maybeSingle(){this.one=true;return this}
    insert(r){this.op='insert';this.p=r;return this} update(p){this.op='update';this.p=p;return this} delete(){this.op='delete';return this}
    then(a,b){return this.run().then(a,b)}
    match(r){return this.f.every(([k,v])=>r[k]===v)}
    async run(){if(this.t==='admins'){const id=this.f[0][1];return{data:db.admins[id]?{user_id:id}:null,error:null}}const rows=T(this.t);const adm=db.session&&db.admins[db.session.user.id];
      if(!adm&&!['products','categories','branches'].includes(this.t))return{data:this.one?null:[],error:null};
      if(this.op==='insert'){const r=Object.assign({created_at:new Date().toISOString(),id:this.t+Date.now()+Math.random()},this.p);if(this.t==='coupons'&&rows.some(x=>x.code===r.code))return{error:{code:'23505',message:'dup'}};rows.push(r);return{data:r,error:null}}
      if(this.op==='update'){rows.filter(r=>this.match(r)).forEach(r=>Object.assign(r,this.p));return{error:null}}
      if(this.op==='delete'){db.tables[this.t]=rows.filter(r=>!this.match(r));return{error:null}}
      let l=rows.filter(r=>this.match(r)).map(r=>{r=Object.assign({},r);if(this.t==='orders'){r.order_items=T('order_items').filter(i=>i.order_id===r.id);r.order_events=T('order_events').filter(i=>i.order_id===r.id);r.order_messages=T('order_messages').filter(i=>i.order_id===r.id)}return r});
      if(this.t==='orders')l.sort((a,b)=>b.order_no-a.order_no);
      return{data:this.one?(l[0]||null):l,error:null}}}
  const client={
    auth:{async getSession(){return{data:{session:db.session}}},onAuthStateChange(cb){db.listeners.push(cb);return{data:{subscription:{}}}},
      async signInWithOtp(){return{error:null}},async verifyOtp({email,token}){if(token!==db.otp)return{error:{message:'Token has expired or is invalid'}};
        const u=Object.values(db.users||{}).find(x=>x.email===email)||{id:'u-'+email,email};db.session={user:u};db.listeners.forEach(f=>f('SIGNED_IN',db.session));return{data:{session:db.session},error:null}},
      async signOut(){db.session=null;return{error:null}},async signInWithOAuth(){return{error:null}}},
    from:t=>new Q(t),
    async rpc(fn,a){if(fn!=='admin_set_order_status')return{error:{message:'nope'}};
      if(!(db.session&&db.admins[db.session.user.id]))return{error:{message:'forbidden'}};
      const o=T('orders').find(x=>x.id===a.p_order);if(!(NEXT[o.status]||[]).includes(a.p_status))return{error:{message:'invalid_transition'}};
      if(a.p_status==='cancelled')T('order_items').filter(i=>i.order_id===o.id).forEach(i=>{T('products').find(p=>p.id===i.product_id).stock+=i.quantity});
      o.status=a.p_status;T('order_events').push({order_id:o.id,status:a.p_status,created_at:new Date().toISOString()});return{error:null}},
    functions:{async invoke(n,{body}){db.emails.push({n,body});return{data:{ok:true},error:null}}},
    storage:{from(){return{async upload(path,blob){db.uploads.push({path,size:blob.size,type:blob.type});return{error:null}},getPublicUrl(p){return{data:{publicUrl:'https://x.supabase.co/storage/v1/object/public/products/'+p}}}}}},
    channel(){const c={on(ev,f,cb){db.rt.push({ev:f,cb});return c},subscribe(){return c}};return c},removeChannel(){}
  };
  window.supabase={createClient:()=>client};
})();
