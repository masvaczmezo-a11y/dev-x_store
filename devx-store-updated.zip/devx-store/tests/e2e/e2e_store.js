// Drives the real store page in Chromium against the in-memory fake Supabase. Run: node e2e_store.js
const { chromium } = require('playwright'); const http = require('http'); const fs = require('fs'); const path = require('path');
const ROOT = path.resolve(__dirname, '../..'); const FAKE = fs.readFileSync(__dirname + '/fake_supabase.js', 'utf8');
const prods = JSON.parse(fs.readFileSync(ROOT + '/data/products.json', 'utf8')).map(p => ({ id: p.id, slug: p.slug, name: p.name, description: p.desc, category: p.cat, price: p.price, old_price: p.old, stock: p.qty, colors: p.colors, sizes: p.sizes, image: p.img, active: true }));
const branches = JSON.parse(fs.readFileSync(ROOT + '/data/branches.json', 'utf8'));
const CSP=fs.readFileSync(path.resolve(__dirname,'../../_headers'),'utf8').match(/Content-Security-Policy: (.*)/)[1];
const srv = http.createServer((q, r) => { let f = path.join(ROOT, decodeURIComponent(q.url.split('?')[0])); if (f.endsWith('/')) f += 'index.html'; fs.readFile(f, (e, d) => { if (e) { r.writeHead(404); r.end(); return } const t = { html: 'text/html', js: 'text/javascript', css: 'text/css', json: 'application/json', webp: 'image/webp', jpg: 'image/jpeg', woff2: 'font/woff2' }[f.split('.').pop()] || 'application/octet-stream'; r.writeHead(200, { 'content-security-policy': CSP, 'content-type': t + '; charset=utf-8' }); r.end(d) }) });
let ok = 0, bad = 0; const T = (n, c) => { if (c) { ok++; console.log('PASS ', n) } else { bad++; console.log('FAIL ', n) } };
(async () => {
  await new Promise(r => srv.listen(0, r)); const base = 'http://127.0.0.1:' + srv.address().port;
  const br = await chromium.launch(); const ctx = await br.newContext({ viewport: { width: 1280, height: 900 }, locale: 'ar-EG' }); const pg = await ctx.newPage();
  const errs = []; pg.on('pageerror', e => errs.push(e.message)); pg.on('console', m => { if (m.type() === 'error' && !/Failed to load resource/.test(m.text())) errs.push(m.text()) });
  await ctx.route('**/supabase.js', r => r.fulfill({ contentType: 'text/javascript', body: FAKE }));
  await ctx.route('**/config.js', r => r.fulfill({ contentType: 'text/javascript', body: 'window.DEVX_CONFIG={SUPABASE_URL:"https://x.supabase.co",SUPABASE_ANON_KEY:"anon",TURNSTILE_SITE_KEY:"",WHATSAPP:"201507410800"}' }));
  await ctx.route('https://fonts.googleapis.com/**', r => r.abort());
  await pg.addInitScript(([p, b]) => { window.__seed = { p, b } }, [prods, branches]);
  // seed the fake DB before app.js runs
  await pg.route('**/api.js', async r => { const resp = await r.fetch(); const body = await resp.text(); r.fulfill({ contentType: 'text/javascript', body: 'window.__fake.products=window.__seed.p;window.__fake.branches=window.__seed.b;window.__fake.admins={};\n' + body }) });
  await pg.goto(base + '/index.html'); await pg.waitForFunction(() => !document.body.classList.contains('booting'));
  T('logged-out visitor lands on login', await pg.evaluate(() => document.querySelector('.v.on').id) === 'login');
  T('no fake OTP / Facebook / password UI left', await pg.evaluate(() => !document.querySelector('#btnFacebook,#pwPw,#tabPw,#googleModal,#gate,#forgot,#admin')));
  T('no code leaks into the login page', !(await pg.content()).includes('123456'));
  await pg.evaluate(() => document.querySelector('[data-go="catalog"]').click()); await pg.waitForTimeout(100);
  T('browsing without login is blocked', await pg.evaluate(() => document.querySelector('.v.on').id) === 'login');
  // ----- Google-only login (the fake auth completes the session the way the OAuth redirect would)
  T('login page has Google only (no e-mail code / Facebook / signup)', await pg.evaluate(() => !!document.querySelector('#btnGoogle') && !document.querySelector('#lgEmail,#otpSend,#lgOtp,#lgGo,#signup,[data-go="signup"]')));
  await pg.click('#btnGoogle'); T('Google button starts the Google OAuth flow', await pg.evaluate(() => window.__fake.oauth && window.__fake.oauth.provider) === 'google');
  await pg.evaluate(async () => { await DX.sb.auth.signInWithOtp({ email: 'sara@example.com' }); await DX.sb.auth.verifyOtp({ email: 'sara@example.com', token: '123456', type: 'email' }) });
  await pg.waitForFunction(() => document.querySelector('.v.on').id === 'home'); T('signed-in user lands on home', true);
  T('logout button hidden-until-login is now visible and red', await pg.evaluate(() => { const b = document.querySelector('#btnLogout'); return getComputedStyle(b).display !== 'none' && getComputedStyle(b).backgroundColor === 'rgb(211, 47, 47)' }));
  T('products rendered from the API (4 cards on home)', await pg.locator('#prods .pc').count() === 4);
  T('admin link hidden for customers', await pg.evaluate(() => getComputedStyle(document.querySelector('#admLink')).display) === 'none');
  // ----- catalogue / details / cart
  await pg.evaluate(() => document.querySelector('[data-go="catalog"]').click()); await pg.waitForSelector('#cg .mu-product');
  T('catalogue shows all 38 products', await pg.locator('#cg .mu-product').count() === 38);
  T('product images are local webp', await pg.evaluate(() => document.querySelector('#cg img.pimg').getAttribute('src').startsWith('assets/products/') && document.querySelector('#cg img.pimg').getAttribute('src').endsWith('.webp')));
  await pg.evaluate(() => { const s = getDevxState(); s.sel = 3; document.querySelector('[data-open="3"]').click() }); await pg.waitForSelector('#details .mu-card');
  await pg.click('#details [data-act="dadd"]'); T('apparel needs size before adding', await pg.evaluate(() => getDevxState().cart.length) === 0);
  await pg.evaluate(() => { document.querySelector('#details [data-act="ps"][data-id="M"]').click() }); await pg.click('#details [data-act="dadd"]');
  T('apparel added with colour+size', await pg.evaluate(() => { const c = getDevxState().cart[0]; return c && c.s === 'M' && c.c === 'أسود فاحم' }));
  await pg.evaluate(() => { document.querySelector('[data-go="cart"]').click() }); await pg.waitForSelector('#cart .sum');
  await pg.fill('#cc', 'NOPE'); await pg.click('[data-act="code"]'); await pg.waitForTimeout(100);
  T('bad coupon rejected by server', await pg.evaluate(() => getDevxState().code) === '');
  await pg.fill('#cc', 'devx10'); await pg.click('[data-act="code"]'); await pg.waitForFunction(() => getDevxState().codePct === 10);
  T('coupon DEVX10 validated through RPC (−10%)', (await pg.locator('#cart .tot').innerText()).includes('216'));
  await pg.evaluate(() => document.querySelector('#cart [data-go="branches"]').click()); await pg.waitForSelector('#bg .bc');
  T('14 branches from API', await pg.locator('#bg .bc').count() === 14);
  await pg.locator('#bg .bc').nth(2).click(); T('branch choice stored', await pg.evaluate(() => getDevxState().br) === 'I Learn (حلوان)');
  await pg.evaluate(() => document.querySelector('#branches [data-go="pay"]').click()); await pg.waitForSelector('#coName');
  // ----- checkout validation + order
  await pg.click('#payBtn'); T('empty checkout form blocked', await pg.evaluate(() => window.__fake.orders.length) === 0);
  await pg.fill('#coName', 'Sara Ali'); await pg.fill('#coPhone', '123'); await pg.click('#payBtn'); T('bad phone blocked client-side', await pg.evaluate(() => window.__fake.orders.length) === 0);
  await pg.fill('#coPhone', '+20 101 234 5678'); await pg.fill('#coGov', 'القاهرة'); await pg.click('#payBtn'); await pg.waitForFunction(() => document.querySelector('.v.on').id === 'confirmation');
  const la = await pg.evaluate(() => window.__fake.lastOrderArgs);
  T('order sent as RPC with normalised phone', la.p_phone === '01012345678' && la.p_branch === 'I Learn (حلوان)' && la.p_coupon === 'DEVX10');
  T('browser sends NO price fields to the server', !JSON.stringify(la).includes('price') && !JSON.stringify(la).includes('total'));
  T('server total (240×0.9=216) shown on confirmation', (await pg.locator('#confirmation').innerText()).includes('216'));
  T('cart cleared + coupon reset after order', await pg.evaluate(() => { const s = getDevxState(); return s.cart.length === 0 && !s.code }));
  T('stock decreased in catalogue data', await pg.evaluate(() => getDevxState().p.find(p => p.id === 3).qty) === 134);
  T('profile phone saved for next time', await pg.evaluate(() => window.__fake.profiles[Object.keys(window.__fake.profiles)[0]].phone) === '01012345678');
  // ----- my orders / cancel
  await pg.evaluate(() => document.querySelector('#dock [data-go="orders"]').click()); await pg.waitForSelector('#orders tbody tr');
  T('my orders lists the server order (#1001)', (await pg.locator('#orders tbody').innerText()).includes('1001'));
  await pg.evaluate(() => document.querySelector('[data-act="trk"]').click()); await pg.waitForFunction(() => document.querySelector('.v.on').id === 'track');
  T('tracking page shows order number', (await pg.locator('#track h2.t').innerText()).includes('1001'));
  await pg.evaluate(() => document.querySelector('#dock [data-go="orders"]').click()); await pg.waitForSelector('[data-act="cancelOrd"]');
  pg.once('dialog', d => d.accept()); await pg.click('[data-act="cancelOrd"]'); await pg.waitForFunction(() => getDevxState().orders[0].status === 'cancelled');
  T('customer can cancel; stock restored', await pg.evaluate(() => getDevxState().p.find(p => p.id === 3).qty) === 135);
  // ----- account
  await pg.evaluate(() => document.querySelector('[data-go="account"]').click()); await pg.waitForSelector('#acN');
  await pg.fill('#acN', 'Sara M Ali'); await pg.click('[data-act="acSave"]'); await pg.waitForTimeout(150);
  T('profile name saved', await pg.evaluate(() => Object.values(window.__fake.profiles)[0].full_name) === 'Sara M Ali');
  await pg.click('[data-act="acTab"][data-id="addr"]'); await pg.fill('#adT', 'البيت'); await pg.fill('#adA', 'القاهرة - مدينة نصر'); await pg.click('[data-act="addAddr"]'); await pg.waitForTimeout(150);
  T('address saved in profile', await pg.evaluate(() => Object.values(window.__fake.profiles)[0].addresses.length) === 1);
  // ----- contact
  await pg.evaluate(() => document.querySelector('[data-go="contact"]').click()); await pg.waitForSelector('#ctN');
  await pg.selectOption('#ctT', { index: 1 }); await pg.fill('#ctM', 'سؤال عن الشحن'); await pg.click('#ctSend'); await pg.waitForTimeout(150);
  T('contact message stored for the logged-in user', await pg.evaluate(() => window.__fake.contacts.length) === 1);
  // ----- persistence + logout
  await pg.reload(); await pg.waitForFunction(() => !document.body.classList.contains('booting'));
  T('session survives reload → straight to the store', await pg.evaluate(() => document.querySelector('.v.on').id) !== 'login');
  await pg.evaluate(() => document.querySelector('[data-go="account"]').click()); await pg.waitForSelector('[data-act="logout"]'); await pg.click('[data-act="logout"]'); await pg.waitForFunction(() => document.querySelector('.v.on').id === 'login');
  T('logout returns to login & clears orders', await pg.evaluate(() => getDevxState().orders.length) === 0);
  // ----- signup removed / logout button / robustness
  T('no signup page or More-menu login links', await pg.evaluate(() => !document.querySelector('#signup,#sheet [data-go="signup"],#sheet [data-go="login"]')));
  await pg.evaluate(async () => { await DX.sb.auth.signInWithOtp({ email: 'sara@example.com' }); await DX.sb.auth.verifyOtp({ email: 'sara@example.com', token: '123456', type: 'email' }) }); await pg.waitForFunction(() => document.querySelector('.v.on').id === 'home');
  await pg.evaluate(() => { history.replaceState(null, '', '#access_token=abc&x=1') }); await pg.reload(); await pg.waitForFunction(() => !document.body.classList.contains('booting'));
  T('garbage URL hash falls back to home with products (no blank page)', await pg.evaluate(() => document.querySelector('.v.on').id) === 'home' && await pg.locator('#prods .pc').count() === 4);
  await pg.evaluate(() => document.querySelector('[data-act="more"]').click()); await pg.click('#btnLogout'); await pg.waitForFunction(() => document.querySelector('.v.on').id === 'login');
  T('red logout button signs out → login', await pg.evaluate(() => !me()));
  // ----- mobile layout smoke
  await pg.setViewportSize({ width: 390, height: 800 }); await pg.evaluate(() => document.querySelector('#dock [data-go="catalog"]').click()); await pg.waitForTimeout(200);
  T('no horizontal scroll on mobile', await pg.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1));
  await pg.screenshot({ path: '/tmp/devx_mobile.png' });
  T('no JS errors during the whole run', errs.length === 0); if (errs.length) console.log(errs.slice(0, 5));
  console.log(`\n${ok} passed, ${bad} failed`); await br.close(); srv.close(); process.exit(bad ? 1 : 0);
})().catch(e => { console.error(e); process.exit(2) });
