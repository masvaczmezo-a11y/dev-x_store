/* In-memory stand-in for supabase-js used ONLY by Playwright tests. Mimics the RPC rules of 0003_functions.sql closely enough to exercise the UI. */
(function(){
  const db={users:{},session:null,orders:[],items:[],profiles:{},contacts:[],coupons:{DEVX10:10},admins:{},seq:1000,listeners:[],otp:'123456',products:null,sent:[]};
  window.__fake=db;
  try{const o=JSON.parse(sessionStorage.getItem('__fakedb')||'null');if(o)Object.assign(db,o,{listeners:[]})}catch(e){}
  const persist=()=>{try{const{listeners,products,branches,...r}=db;sessionStorage.setItem('__fakedb',JSON.stringify(r))}catch(e){}};
  setInterval(persist,50);
  const sbErr=m=>({message:m});
  const client={
    auth:{
      async getSession(){return{data:{session:db.session}}},
      onAuthStateChange(cb){db.listeners.push(cb);return{data:{subscription:{}}}},
      async signInWithOAuth(o){db.oauth=o;return{error:null}},
      async signInWithOtp({email,options}){db.sent.push({email,options});
        if(options&&options.captchaToken==='BAD')return{error:sbErr('captcha verification process failed')};
        db.pending={email,data:(options&&options.data)||{}};return{error:null}},
      async verifyOtp({email,token,type}){
        if(!db.pending||db.pending.email!==email||token!==db.otp||type!=='email')return{data:null,error:sbErr('Token has expired or is invalid')};
        let u=Object.values(db.users).find(x=>x.email===email);
        if(!u){u={id:'u'+Object.keys(db.users).length,email,user_metadata:db.pending.data};db.users[u.id]=u;
          const ph=String(db.pending.data.phone||'');db.profiles[u.id]={id:u.id,full_name:db.pending.data.full_name||email.split('@')[0],email,phone:/^01[0125]\d{8}$/.test(ph)?ph:null,addresses:[]}}
        db.session={user:u,access_token:'t'};db.listeners.forEach(f=>f('SIGNED_IN',db.session));return{data:{session:db.session},error:null}},
      async signOut(){db.session=null;db.listeners.forEach(f=>f('SIGNED_OUT',null));return{error:null}}
    },
    from(t){return new Q(t)},
    async rpc(fn,a){return rpcs[fn](a)},
    channel(){const c={on(){return c},subscribe(){return c}};return c},
    removeChannel(){}
  };
  class Q{constructor(t){this.t=t;this.f=[];this.op='select';this.o=null}
    select(){if(this.op==='select')this.op='select';return this} eq(k,v){this.f.push([k,v]);return this} order(){return this}
    update(p){this.op='update';this.p=p;return this} insert(r){this.op='insert';this.p=r;return this}
    single(){this.one=true;return this} maybeSingle(){this.one=true;this.maybe=true;return this}
    then(res,rej){return this.run().then(res,rej)}
    async run(){
      const u=db.session&&db.session.user.id;
      if(this.t==='products'){return{data:db.products,error:null}}
      if(this.t==='branches'){return{data:db.branches.map(name=>({name})),error:null}}
      if(this.t==='profiles'){const id=this.f.find(x=>x[0]==='id')[1];
        if(this.op==='update'){if(id!==u)return{data:null,error:sbErr('rls')};Object.assign(db.profiles[id],this.p);return{data:db.profiles[id],error:null}}
        return{data:db.profiles[id]||null,error:null}}
      if(this.t==='admins'){const id=this.f.find(x=>x[0]==='user_id')[1];return{data:db.admins[id]?{user_id:id}:null,error:null}}
      if(this.t==='orders'){const l=db.orders.filter(o=>o.user_id===u).map(o=>Object.assign({},o,{order_items:db.items.filter(i=>i.order_id===o.id)})).reverse();return{data:l,error:null}}
      if(this.t==='contact_messages'){if(!u||this.p.user_id!==u)return{data:null,error:sbErr('new row violates row-level security policy')};db.contacts.push(this.p);return{error:null}}
      return{data:[],error:null}}}
  const rpcs={
    async validate_coupon({p_code}){return{data:db.coupons[String(p_code).trim().toUpperCase()]||null,error:null}},
    async create_order(a){
      const u=db.session&&db.session.user.id;if(!u)return{error:sbErr('not_authenticated')};
      db.lastOrderArgs=a;
      if(a.p_name.trim().length<3)return{error:sbErr('invalid_name')};
      if(!/^01[0125]\d{8}$/.test(a.p_phone))return{error:sbErr('invalid_phone')};
      let pct=0;if(a.p_coupon){pct=db.coupons[a.p_coupon];if(!pct)return{error:sbErr('invalid_coupon')}}
      const used={};let sub=0;const lines=[];
      for(const it of a.p_items){const p=db.products.find(x=>x.id===it.product_id&&x.active);if(!p)return{error:sbErr('product_unavailable')};
        used[p.id]=(used[p.id]||0)+it.quantity;if(used[p.id]>p.stock)return{error:{message:'insufficient_stock',details:p.name}};
        if(p.sizes.length&&!it.size)return{error:{message:'size_required',details:p.name}};
        lines.push({p,it});sub+=p.price*it.quantity}
      const o={id:'o'+(++db.seq),order_no:db.seq,user_id:u,customer_name:a.p_name,customer_phone:a.p_phone,branch:a.p_branch,payment_method:a.p_payment,subtotal:sub,
        total:Math.round(sub*(100-pct))/100,status:'new',created_at:new Date().toISOString()};
      db.orders.push(o);lines.forEach(({p,it})=>{p.stock-=it.quantity;db.items.push({order_id:o.id,product_name:p.name,unit_price:p.price,quantity:it.quantity,color:it.color,size:it.size})});
      return{data:{id:o.id,order_no:o.order_no,total:o.total,subtotal:sub,status:'new'},error:null}},
    async cancel_my_order({p_order}){const o=db.orders.find(x=>x.id===p_order);if(!o)return{error:sbErr('not_found')};if(!['new','preparing'].includes(o.status))return{error:sbErr('cannot_cancel')};
      o.status='cancelled';db.items.filter(i=>i.order_id===o.id).forEach(i=>{db.products.find(p=>p.name===i.product_name).stock+=i.quantity});return{error:null}},
    async delete_my_account(){const u=db.session.user.id;delete db.users[u];delete db.profiles[u];db.orders.forEach(o=>{if(o.user_id===u)o.user_id=null});return{error:null}}
  };
  window.supabase={createClient(){return client}};
})();
